﻿using System;
using System.Collections.Generic;

namespace CoreAPI.Models;

public partial class TblUser
{
    public int TblUserId { get; set; }

    public string? UserName { get; set; }

    public string? Password { get; set; }
}
