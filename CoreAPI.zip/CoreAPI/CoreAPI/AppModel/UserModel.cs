﻿namespace CoreAPI.AppModel
{
    public class UserModel
    {
        public int ID { get; set; }

        public string? UserName { get; set; }

        public string? Password { get; set; }
        public string UserMessage { get; set; }
        public string AccessToken { get; set; }

        public DateTime? CreatedDate { get; set; }
    }

    public class Common
    {
        public int EmployeeId { get; set; }

        public string Name { get; set; } = null!;

        public bool IsActive { get; set; }

        public DateTime JoinDate { get; set; }
        public IFormFile? ImgFile { get; set; }
        public string ImgName { get; set; }
        public string Experiences { get; set; }
    }

    public class ImgUpload
    {
        public int ImgId { get; set; }
        public string ImgName { get; set; }
        public IFormFile? ImgFile { get; set; }
    }
}
