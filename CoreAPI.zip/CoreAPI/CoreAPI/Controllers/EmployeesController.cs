﻿
using CoreAPI.AppModel;
using CoreAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CoreApiEvidence.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        public static IWebHostEnvironment _environment;
        private readonly CoreApiOneDbContext _db;

        public EmployeesController(CoreApiOneDbContext db,IWebHostEnvironment environment)
        {
            _db = db;
            _environment = environment;
        }

        //public EmployeesController(FinalApiDbContext db, IWebHostEnvironment environment)
        //{
        //    _db = db;
        //    _environment = environment;
        //}

        [HttpGet]
        public IActionResult GetAllEmployees()
        {
            var result = (from emp in _db.Employees
                          join exp in _db.Experiences on emp.EmployeeId equals exp.EmployeeId into experiences
                          select new
                          {
                              emp.EmployeeId,
                              emp.Name,
                              emp.JoinDate,
                              emp.ImageUrl,
                              emp.ImageName,
                              Experiences = experiences.Select(e => new
                              {
                                  e.Title,
                                  e.Duration
                              })
                          }).ToList();

            return Ok(result);
        }

        //public System.Object GetAllEmployees()
        // {

        //    var result = (from emp in _db.Employees
        //                  select new
        //                  {
        //                      emp.EmployeeId,
        //                      emp.Name,
        //                      emp.JoinDate,
        //                      emp.ImageUrl,
        //                      emp.ImageName,
        //                      emp.Experiences
        //                  }).ToList();
        //    return result;
        //}

        [HttpGet("{employeeId}")]
        public IActionResult GetEmployeeWithExperiences(int employeeId)
        {
            var result = (from emp in _db.Employees
                          where emp.EmployeeId == employeeId
                          select new
                          {
                              emp.EmployeeId,
                              emp.Name,
                              emp.JoinDate,
                              emp.ImageUrl,
                              emp.ImageName,
                              Experiences = _db.Experiences
                                  .Where(exp => exp.EmployeeId == employeeId)
                                  .Select(exp => new
                                  {
                                      exp.Title,
                                      exp.Duration
                                  })
                                  .ToList()
                          })
                         .FirstOrDefault();

            if (result == null)
            {
                return NotFound("Employee not found.");
            }

            return Ok(result);
        }







        [HttpPost]
        public async Task<IActionResult> PostEmployee([FromForm] Common objCommon)
        {
            ImgUpload FileApi = new ImgUpload();
            string fileName = objCommon.ImgName + ".jpg";
            FileApi.ImgName = "\\Upload\\" + fileName;
            if (objCommon.ImgFile?.Length > 0)
            {
                if (!Directory.Exists(_environment.WebRootPath + "\\Upload"))
                {
                    Directory.CreateDirectory(_environment.WebRootPath + "\\Upload\\");
                }
                using (FileStream fileStream = System.IO.File.Create(_environment.WebRootPath + "\\Upload" + objCommon.ImgFile.FileName))
                {
                    objCommon.ImgFile.CopyTo(fileStream);
                    fileStream.Flush();
                }
            }

            Employee empObj = new Employee();
            empObj.Name = objCommon.Name;
            empObj.IsActive = objCommon.IsActive;
            empObj.JoinDate = objCommon.JoinDate;
            empObj.ImageName = objCommon.ImgName;
            empObj.ImageUrl = FileApi.ImgName;
            _db.Add(empObj);
            await _db.SaveChangesAsync();

            List<Experience> list = JsonConvert.DeserializeObject<List<Experience>>(objCommon.Experiences);

            var emp = _db.Employees.FirstOrDefault(x => x.Name == objCommon.Name);

            if (list != null && list.Count > 0)
            {
                foreach (var item in list)
                {
                    Experience objEx = new Experience
                    {
                        EmployeeId = empObj.EmployeeId,
                        Title = item.Title,
                        Duration = item.Duration,
                    };
                    _db.Experiences.Add(objEx);
                }
                await _db.SaveChangesAsync();
            }

            return Ok("Employee created successfully.");
        }

        [HttpPut("{employeeId}")]
        public async Task<IActionResult> UpdateEmployee(int employeeId, [FromForm] Common objCommon)
        {
            var empObj = await _db.Employees.FindAsync(employeeId);
            if (empObj == null)
            {
                return NotFound("Employee not found.");
            }

            ImgUpload FileApi = new ImgUpload();
            string fileName = objCommon.ImgName + ".jpg";
            FileApi.ImgName = "\\Upload\\" + fileName;
            if (objCommon.ImgFile?.Length > 0)
            {
                if (!Directory.Exists(_environment.WebRootPath + "\\Upload"))
                {
                    Directory.CreateDirectory(_environment.WebRootPath + "\\Upload\\");
                }
                using (FileStream fileStream = System.IO.File.Create(_environment.WebRootPath + "\\Upload" + objCommon.ImgFile.FileName))
                {
                    objCommon.ImgFile.CopyTo(fileStream);
                    fileStream.Flush();
                }
            }

            empObj.Name = objCommon.Name;
            empObj.IsActive = objCommon.IsActive;
            empObj.JoinDate = objCommon.JoinDate;
            empObj.ImageName = objCommon.ImgName;
            empObj.ImageUrl = FileApi.ImgName;

            List<Experience> list = JsonConvert.DeserializeObject<List<Experience>>(objCommon.Experiences);

            // Remove existing experiences for the employee
            var existingExperiences = _db.Experiences.Where(e => e.EmployeeId == employeeId);
            _db.Experiences.RemoveRange(existingExperiences);

            if (list != null && list.Count > 0)
            {
                foreach (var item in list)
                {
                    Experience objEx = new Experience
                    {
                        EmployeeId = empObj.EmployeeId,
                        Title = item.Title,
                        Duration = item.Duration,
                    };
                    _db.Experiences.Add(objEx);
                }
            }

            await _db.SaveChangesAsync();

            return Ok("Employee updated successfully.");
        }


        [HttpDelete("{employeeId}")]
        public async Task<IActionResult> DeleteEmployee(int employeeId)
        {
            var empObj = await _db.Employees.FindAsync(employeeId);
            if (empObj == null)
            {
                return NotFound("Employee not found.");
            }

            _db.Employees.Remove(empObj);
            await _db.SaveChangesAsync();

            return Ok("Employee deleted successfully.");
        }
    }
}
